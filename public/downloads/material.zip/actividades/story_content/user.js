function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5Ywbk9jiwVA":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

