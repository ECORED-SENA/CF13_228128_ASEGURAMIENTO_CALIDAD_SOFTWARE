function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6hN7Rbi2aw0":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

